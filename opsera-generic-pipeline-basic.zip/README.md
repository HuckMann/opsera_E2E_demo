# Opsera Generic Pipeline (Basic)
This is the basic repo scaffold (FastAPI microservices, Helm, Terraform, CI).